package com.cbs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CbsBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
