package com.cbs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CbsBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(CbsBackendApplication.class, args);
	}

}
